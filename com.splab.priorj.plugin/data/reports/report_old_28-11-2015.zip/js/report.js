var coverage = [];

var coverageGlobal = {
	
};

$(function(){
	loadData();
});

function loadData(){
	
}

	function getCoverageReportData(){
		return coverage;
	}

	function getCoverageGlobalData(){
		return coverageGlobal;
	}

