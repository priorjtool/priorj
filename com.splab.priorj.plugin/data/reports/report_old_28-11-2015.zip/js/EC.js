var ecTests = new Array();

$(function(){
	loadListEC();
});

function loadListEC(){
	
}

function getOrderEC(){
	return ecTests;
}

function getECPosition(testName){
	return ecTests[testName];
}
