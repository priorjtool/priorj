
$(function(){

	Helper.setFailures(getFailures());
	Helper.setOrder('amc', getOrderAMC());
	Helper.setOrder('asc', getOrderASC());
	Helper.setOrder('cb', getOrderCB());
	Helper.setOrder('rnd', getOrderRND());
	Helper.setOrder('tmc', getOrderTMC());
	Helper.setOrder('tsc', getOrderTSC());
	Helper.setOrder('ec', getOrderEC());
	Helper.getF1Measure();


	var f1Measure = Helper.getF1Measure();

	f1Measure.forEach(function(f1){
		var item = f1.name;
		var position = f1.value;
		$('#f1').append('<li class="list-group-item list-group-item-info" title="'+item+'">' + item + '<span class="badge pull-right">'+position+'</span></li>');
	});

	
});