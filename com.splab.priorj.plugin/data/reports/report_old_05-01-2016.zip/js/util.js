var Util = (function(){
  
  function contains(oneArray, element){
	for(var i=0; i<oneArray.length;i++){
		if (oneArray[i] === element){
			return true;
		}
	}
    return false;
  }
  
  function sum(oneArray){
    var total=0; 
    oneArray.forEach(function(element){
       total += element;
     });
    return total;
  }
  
  function percentage(value, total){
    p = value * 100 / total; 
    p = p.toFixed(2);
    return p;
  }

  function containsObjectAdapted(adaptedList, element) {
      for(i in adaptedList){
          if (adaptedList[i].change === element.change){
              return i;
          }
      }
      return -1;
  }

  return {
    contains : function (oneArray,element){
      return contains(oneArray, element);
    } ,
    sum : function(oneArray){
      return sum(oneArray);
    },
    percentage : function (value, total){
      return percentage(value, total);
    },
    containsObjectAdapted : function(adaptedList, element) {
      return containsObjectAdapted(adaptedList, element);
    }
  };
})();