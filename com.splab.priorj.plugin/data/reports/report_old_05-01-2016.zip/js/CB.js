var cbTests = new Array();

$(function(){
	loadListCB();
});

function loadListCB(){
	
}

function getOrderCB(){
	return cbTests;
}

function getCBPosition(testName){
	return cbTests[testName];
}
