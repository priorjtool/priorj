var treeData = (function(){
	var suites = [];
	function init(){
		suites.push({
			name : 'ArvoreAVLTest',
			testcase : {
				name: 'testGetRaiz_fixture_1',
				classcode : {
					name : 'AVLImpl',
					method : {
						name : 'getRaiz()',
						lines : [12, 14]
					}
				}
			}
		});
		suites.push({
			name : 'ArvoreAVLTest',
			testcase : {
				name: 'testInserir_fixture_1',
				classcode : {
					name : 'AVLImpl',
					method : {
						name : 'inserir(int)',
						lines : [45]
					}
				}
			}
		});
		suites.push({
			name : 'ArvoreAVLTest',
			testcase : {
				name: 'testInserir_fixture_1',
				classcode : {
					name : 'AVLImpl',
					method : {
						name : 'pesquisar(int)',
						lines : [69]
					}
				}
			}
		});
		suites.push({
			name : 'ArvoreAVLTest',
			testcase : {
				name: 'testInserir_fixture_1',
				classcode : {
					name : 'AVLImpl',
					method : {
						name : 'pesquisarNo(No, int)',
						lines : [370, 372, 50, 52, 54]
					}
				}
			}
		});
		suites.push({
			name : 'ArvoreAVLTest',
			testcase : {
				name: 'testInserir_fixture_2',
				classcode : {
					name : 'AVLImpl',
					method : {
						name : 'inserir(int)',
						lines : [45]
					}
				}
			}
		});
		suites.push({
			name : 'ArvoreAVLTest',
			testcase : {
				name: 'testInserir_fixture_2',
				classcode : {
					name : 'AVLImpl',
					method : {
						name : 'pesquisar(int)',
						lines : [69]
					}
				}
			}
		});
		suites.push({
			name : 'ArvoreAVLTest',
			testcase : {
				name: 'testInserir_fixture_2',
				classcode : {
					name : 'AVLImpl',
					method : {
						name : 'pesquisarNo(No, int)',
						lines : [370, 372, 50, 52, 54]
					}
				}
			}
		});
		suites.push({
			name : 'ArvoreAVLTest',
			testcase : {
				name: 'testInserir_fixture_3',
				classcode : {
					name : 'AVLImpl',
					method : {
						name : 'inserir(int)',
						lines : [45]
					}
				}
			}
		});
		suites.push({
			name : 'ArvoreAVLTest',
			testcase : {
				name: 'testInserir_fixture_3',
				classcode : {
					name : 'AVLImpl',
					method : {
						name : 'pesquisar(int)',
						lines : [69]
					}
				}
			}
		});
		suites.push({
			name : 'ArvoreAVLTest',
			testcase : {
				name: 'testInserir_fixture_3',
				classcode : {
					name : 'AVLImpl',
					method : {
						name : 'pesquisarNo(No, int)',
						lines : [370, 372, 50, 52, 54]
					}
				}
			}
		});
		suites.push({
			name : 'ArvoreAVLTest',
			testcase : {
				name: 'testGetAltura_fixture_1',
				classcode : {
					name : 'AVLImpl',
					method : {
						name : 'getAltura(No)',
						lines : [23]
					}
				}
			}
		});
		suites.push({
			name : 'ArvoreAVLTest',
			testcase : {
				name: 'testPercorrePreOrdem_fixture_1',
				classcode : {
					name : 'AVLImpl',
					method : {
						name : 'percorrePreOrdem()',
						lines : [29]
					}
				}
			}
		});
		suites.push({
			name : 'ArvoreAVLTest',
			testcase : {
				name: 'testPesquisar_fixture_1',
				classcode : {
					name : 'AVLImpl',
					method : {
						name : 'pesquisar(int)',
						lines : [69]
					}
				}
			}
		});
		suites.push({
			name : 'ArvoreAVLTest',
			testcase : {
				name: 'testPesquisar_fixture_1',
				classcode : {
					name : 'AVLImpl',
					method : {
						name : 'pesquisarNo(No, int)',
						lines : [370, 372]
					}
				}
			}
		});
		suites.push({
			name : 'ArvoreAVLTest',
			testcase : {
				name: 'testPesquisar_fixture_2',
				classcode : {
					name : 'AVLImpl',
					method : {
						name : 'pesquisar(int)',
						lines : [69]
					}
				}
			}
		});
		suites.push({
			name : 'ArvoreAVLTest',
			testcase : {
				name: 'testPesquisar_fixture_2',
				classcode : {
					name : 'AVLImpl',
					method : {
						name : 'pesquisarNo(No, int)',
						lines : [370, 372]
					}
				}
			}
		});
		suites.push({
			name : 'ArvoreAVLTest',
			testcase : {
				name: 'testPesquisar_fixture_3',
				classcode : {
					name : 'AVLImpl',
					method : {
						name : 'pesquisar(int)',
						lines : [69]
					}
				}
			}
		});
		suites.push({
			name : 'ArvoreAVLTest',
			testcase : {
				name: 'testPesquisar_fixture_3',
				classcode : {
					name : 'AVLImpl',
					method : {
						name : 'pesquisarNo(No, int)',
						lines : [370, 372]
					}
				}
			}
		});
		suites.push({
			name : 'ArvoreAVLTest',
			testcase : {
				name: 'testPercorrePosOrdem_fixture_1',
				classcode : {
					name : 'AVLImpl',
					method : {
						name : 'percorrePosOrdem()',
						lines : [37]
					}
				}
			}
		});
		suites.push({
			name : 'ArvoreAVLTest',
			testcase : {
				name: 'testGetRaiz_fixture_1',
				classcode : {
					name : 'AVLImpl',
					method : {
						name : 'getRaiz()',
						lines : [12, 14]
					}
				}
			}
		});
		suites.push({
			name : 'AVLImplTest',
			testcase : {
				name: 'testSetAltura_fixture4_3',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'AVLImplTest',
			testcase : {
				name: 'testSetAltura_fixture4_3',
				classcode : {
					name : 'No',
					method : {
						name : 'setDireita(No)',
						lines : [66]
					}
				}
			}
		});
		suites.push({
			name : 'AVLImplTest',
			testcase : {
				name: 'testSetAltura_fixture4_3',
				classcode : {
					name : 'No',
					method : {
						name : 'setEsquerda(No)',
						lines : [54]
					}
				}
			}
		});
		suites.push({
			name : 'AVLImplTest',
			testcase : {
				name: 'testSetAltura_fixture4_3',
				classcode : {
					name : 'No',
					method : {
						name : 'setPai(No)',
						lines : [42]
					}
				}
			}
		});
		suites.push({
			name : 'AVLImplTest',
			testcase : {
				name: 'testSetAltura_fixture4_3',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'AVLImplTest',
			testcase : {
				name: 'testInserir_fixture_1',
				classcode : {
					name : 'AVLImpl',
					method : {
						name : 'inserir(int)',
						lines : [45, 47]
					}
				}
			}
		});
		suites.push({
			name : 'AVLImplTest',
			testcase : {
				name: 'testInserir_fixture_2',
				classcode : {
					name : 'AVLImpl',
					method : {
						name : 'inserir(int)',
						lines : [45]
					}
				}
			}
		});
		suites.push({
			name : 'AVLImplTest',
			testcase : {
				name: 'testInserir_fixture_2',
				classcode : {
					name : 'AVLImpl',
					method : {
						name : 'pesquisar(int)',
						lines : [69]
					}
				}
			}
		});
		suites.push({
			name : 'AVLImplTest',
			testcase : {
				name: 'testInserir_fixture_2',
				classcode : {
					name : 'AVLImpl',
					method : {
						name : 'pesquisarNo(No, int)',
						lines : [370, 372, 50, 52, 54]
					}
				}
			}
		});
		suites.push({
			name : 'AVLImplTest',
			testcase : {
				name: 'testGetAltura_fixture_1',
				classcode : {
					name : 'AVLImpl',
					method : {
						name : 'getAltura(No)',
						lines : [23]
					}
				}
			}
		});
		suites.push({
			name : 'AVLImplTest',
			testcase : {
				name: 'testPercorrePreOrdem_fixture_1',
				classcode : {
					name : 'AVLImpl',
					method : {
						name : 'percorrePreOrdem()',
						lines : [29]
					}
				}
			}
		});
		suites.push({
			name : 'AVLImplTest',
			testcase : {
				name: 'testPesquisar_fixture_1',
				classcode : {
					name : 'AVLImpl',
					method : {
						name : 'pesquisar(int)',
						lines : [69]
					}
				}
			}
		});
		suites.push({
			name : 'AVLImplTest',
			testcase : {
				name: 'testPesquisar_fixture_1',
				classcode : {
					name : 'AVLImpl',
					method : {
						name : 'pesquisarNo(No, int)',
						lines : [370, 372]
					}
				}
			}
		});
		suites.push({
			name : 'AVLImplTest',
			testcase : {
				name: 'testPesquisar_fixture_2',
				classcode : {
					name : 'AVLImpl',
					method : {
						name : 'pesquisar(int)',
						lines : [69]
					}
				}
			}
		});
		suites.push({
			name : 'AVLImplTest',
			testcase : {
				name: 'testPesquisar_fixture_2',
				classcode : {
					name : 'AVLImpl',
					method : {
						name : 'pesquisarNo(No, int)',
						lines : [370, 372]
					}
				}
			}
		});
		suites.push({
			name : 'AVLImplTest',
			testcase : {
				name: 'testPesquisar_fixture_3',
				classcode : {
					name : 'AVLImpl',
					method : {
						name : 'pesquisar(int)',
						lines : [69]
					}
				}
			}
		});
		suites.push({
			name : 'AVLImplTest',
			testcase : {
				name: 'testPesquisar_fixture_3',
				classcode : {
					name : 'AVLImpl',
					method : {
						name : 'pesquisarNo(No, int)',
						lines : [370, 372]
					}
				}
			}
		});
		suites.push({
			name : 'AVLImplTest',
			testcase : {
				name: 'testPercorrePosOrdem_fixture_1',
				classcode : {
					name : 'AVLImpl',
					method : {
						name : 'percorrePosOrdem()',
						lines : [37]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetPai_fixture1_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getPai()',
						lines : [36]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetPai_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetPai_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setDireita(No)',
						lines : [66]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetPai_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setEsquerda(No)',
						lines : [54]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetPai_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setPai(No)',
						lines : [42]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetPai_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getPai()',
						lines : [36]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetPai_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getAltura()',
						lines : [24]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetPai_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getPai()',
						lines : [36]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetPai_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getValor()',
						lines : [18]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetPai_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getDireita()',
						lines : [60]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetPai_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getEsquerda()',
						lines : [48]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetPai_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetPai_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setDireita(No)',
						lines : [66]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetPai_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setEsquerda(No)',
						lines : [54]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetPai_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setPai(No)',
						lines : [42]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetPai_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getPai()',
						lines : [36]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetPai_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getAltura()',
						lines : [24]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetPai_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getPai()',
						lines : [36]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetPai_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getValor()',
						lines : [18]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetPai_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getDireita()',
						lines : [60]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetPai_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getEsquerda()',
						lines : [48]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetPai_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetPai_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setDireita(No)',
						lines : [66]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetPai_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setEsquerda(No)',
						lines : [54]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetPai_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setPai(No)',
						lines : [42]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetPai_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getPai()',
						lines : [36]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetPai_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getAltura()',
						lines : [24]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetPai_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getPai()',
						lines : [36]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetPai_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getValor()',
						lines : [18]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetPai_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getDireita()',
						lines : [60]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetPai_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getEsquerda()',
						lines : [48]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetAltura_fixture1_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getAltura()',
						lines : [24]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetAltura_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetAltura_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setDireita(No)',
						lines : [66]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetAltura_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setEsquerda(No)',
						lines : [54]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetAltura_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setPai(No)',
						lines : [42]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetAltura_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getAltura()',
						lines : [24]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetAltura_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetAltura_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setDireita(No)',
						lines : [66]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetAltura_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setEsquerda(No)',
						lines : [54]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetAltura_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setPai(No)',
						lines : [42]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetAltura_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getAltura()',
						lines : [24]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetAltura_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetAltura_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setDireita(No)',
						lines : [66]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetAltura_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setEsquerda(No)',
						lines : [54]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetAltura_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setPai(No)',
						lines : [42]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetAltura_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getAltura()',
						lines : [24]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testNo_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getAltura()',
						lines : [24]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testNo_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getPai()',
						lines : [36]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testNo_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getValor()',
						lines : [18]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testNo_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getDireita()',
						lines : [60]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testNo_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getEsquerda()',
						lines : [48]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testNo_2',
				classcode : {
					name : 'No',
					method : {
						name : 'getAltura()',
						lines : [24]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testNo_2',
				classcode : {
					name : 'No',
					method : {
						name : 'getPai()',
						lines : [36]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testNo_2',
				classcode : {
					name : 'No',
					method : {
						name : 'getValor()',
						lines : [18]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testNo_2',
				classcode : {
					name : 'No',
					method : {
						name : 'getDireita()',
						lines : [60]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testNo_2',
				classcode : {
					name : 'No',
					method : {
						name : 'getEsquerda()',
						lines : [48]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testNo_3',
				classcode : {
					name : 'No',
					method : {
						name : 'getAltura()',
						lines : [24]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testNo_3',
				classcode : {
					name : 'No',
					method : {
						name : 'getPai()',
						lines : [36]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testNo_3',
				classcode : {
					name : 'No',
					method : {
						name : 'getValor()',
						lines : [18]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testNo_3',
				classcode : {
					name : 'No',
					method : {
						name : 'getDireita()',
						lines : [60]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testNo_3',
				classcode : {
					name : 'No',
					method : {
						name : 'getEsquerda()',
						lines : [48]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetEsquerda_fixture1_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setEsquerda(No)',
						lines : [54]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetEsquerda_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetEsquerda_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setDireita(No)',
						lines : [66]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetEsquerda_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setEsquerda(No)',
						lines : [54]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetEsquerda_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setPai(No)',
						lines : [42]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetEsquerda_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setEsquerda(No)',
						lines : [54]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetEsquerda_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetEsquerda_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setDireita(No)',
						lines : [66]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetEsquerda_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setEsquerda(No)',
						lines : [54]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetEsquerda_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setPai(No)',
						lines : [42]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetEsquerda_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setEsquerda(No)',
						lines : [54]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetEsquerda_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetEsquerda_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setDireita(No)',
						lines : [66]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetEsquerda_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setEsquerda(No)',
						lines : [54]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetEsquerda_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setPai(No)',
						lines : [42]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetEsquerda_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setEsquerda(No)',
						lines : [54]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetDireita_fixture1_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setDireita(No)',
						lines : [66]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetDireita_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetDireita_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setDireita(No)',
						lines : [66]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetDireita_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setEsquerda(No)',
						lines : [54]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetDireita_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setPai(No)',
						lines : [42]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetDireita_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setDireita(No)',
						lines : [66]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetDireita_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetDireita_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setDireita(No)',
						lines : [66]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetDireita_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setEsquerda(No)',
						lines : [54]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetDireita_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setPai(No)',
						lines : [42]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetDireita_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setDireita(No)',
						lines : [66]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetDireita_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetDireita_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setDireita(No)',
						lines : [66]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetDireita_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setEsquerda(No)',
						lines : [54]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetDireita_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setPai(No)',
						lines : [42]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetDireita_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setDireita(No)',
						lines : [66]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetValor_fixture1_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getValor()',
						lines : [18]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetValor_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetValor_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setDireita(No)',
						lines : [66]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetValor_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setEsquerda(No)',
						lines : [54]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetValor_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setPai(No)',
						lines : [42]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetValor_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getValor()',
						lines : [18]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetValor_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetValor_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setDireita(No)',
						lines : [66]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetValor_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setEsquerda(No)',
						lines : [54]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetValor_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setPai(No)',
						lines : [42]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetValor_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getValor()',
						lines : [18]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetValor_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetValor_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setDireita(No)',
						lines : [66]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetValor_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setEsquerda(No)',
						lines : [54]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetValor_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setPai(No)',
						lines : [42]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetValor_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getValor()',
						lines : [18]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetDireita_fixture1_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getDireita()',
						lines : [60]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetDireita_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetDireita_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setDireita(No)',
						lines : [66]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetDireita_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setEsquerda(No)',
						lines : [54]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetDireita_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setPai(No)',
						lines : [42]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetDireita_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getDireita()',
						lines : [60]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetDireita_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getAltura()',
						lines : [24]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetDireita_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getPai()',
						lines : [36]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetDireita_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getValor()',
						lines : [18]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetDireita_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getDireita()',
						lines : [60]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetDireita_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getEsquerda()',
						lines : [48]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetDireita_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetDireita_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setDireita(No)',
						lines : [66]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetDireita_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setEsquerda(No)',
						lines : [54]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetDireita_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setPai(No)',
						lines : [42]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetDireita_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getDireita()',
						lines : [60]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetDireita_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getAltura()',
						lines : [24]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetDireita_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getPai()',
						lines : [36]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetDireita_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getValor()',
						lines : [18]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetDireita_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getDireita()',
						lines : [60]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetDireita_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getEsquerda()',
						lines : [48]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetDireita_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetDireita_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setDireita(No)',
						lines : [66]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetDireita_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setEsquerda(No)',
						lines : [54]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetDireita_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setPai(No)',
						lines : [42]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetDireita_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getDireita()',
						lines : [60]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetDireita_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getAltura()',
						lines : [24]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetDireita_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getPai()',
						lines : [36]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetDireita_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getValor()',
						lines : [18]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetDireita_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getDireita()',
						lines : [60]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetDireita_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getEsquerda()',
						lines : [48]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetPai_fixture1_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setPai(No)',
						lines : [42]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetPai_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetPai_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setDireita(No)',
						lines : [66]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetPai_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setEsquerda(No)',
						lines : [54]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetPai_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setPai(No)',
						lines : [42]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetPai_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setPai(No)',
						lines : [42]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetPai_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetPai_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setDireita(No)',
						lines : [66]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetPai_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setEsquerda(No)',
						lines : [54]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetPai_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setPai(No)',
						lines : [42]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetPai_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setPai(No)',
						lines : [42]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetPai_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetPai_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setDireita(No)',
						lines : [66]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetPai_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setEsquerda(No)',
						lines : [54]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetPai_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setPai(No)',
						lines : [42]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetPai_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setPai(No)',
						lines : [42]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetEsquerda_fixture1_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getEsquerda()',
						lines : [48]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetEsquerda_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetEsquerda_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setDireita(No)',
						lines : [66]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetEsquerda_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setEsquerda(No)',
						lines : [54]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetEsquerda_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setPai(No)',
						lines : [42]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetEsquerda_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getEsquerda()',
						lines : [48]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetEsquerda_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getAltura()',
						lines : [24]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetEsquerda_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getPai()',
						lines : [36]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetEsquerda_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getValor()',
						lines : [18]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetEsquerda_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getDireita()',
						lines : [60]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetEsquerda_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getEsquerda()',
						lines : [48]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetEsquerda_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetEsquerda_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setDireita(No)',
						lines : [66]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetEsquerda_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setEsquerda(No)',
						lines : [54]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetEsquerda_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setPai(No)',
						lines : [42]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetEsquerda_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getEsquerda()',
						lines : [48]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetEsquerda_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getAltura()',
						lines : [24]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetEsquerda_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getPai()',
						lines : [36]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetEsquerda_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getValor()',
						lines : [18]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetEsquerda_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getDireita()',
						lines : [60]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetEsquerda_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getEsquerda()',
						lines : [48]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetEsquerda_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetEsquerda_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setDireita(No)',
						lines : [66]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetEsquerda_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setEsquerda(No)',
						lines : [54]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetEsquerda_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setPai(No)',
						lines : [42]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetEsquerda_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getEsquerda()',
						lines : [48]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetEsquerda_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getAltura()',
						lines : [24]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetEsquerda_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getPai()',
						lines : [36]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetEsquerda_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getValor()',
						lines : [18]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetEsquerda_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getDireita()',
						lines : [60]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testGetEsquerda_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'getEsquerda()',
						lines : [48]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture1_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture1_2',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture1_3',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setDireita(No)',
						lines : [66]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setEsquerda(No)',
						lines : [54]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setPai(No)',
						lines : [42]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture2_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture2_2',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture2_2',
				classcode : {
					name : 'No',
					method : {
						name : 'setDireita(No)',
						lines : [66]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture2_2',
				classcode : {
					name : 'No',
					method : {
						name : 'setEsquerda(No)',
						lines : [54]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture2_2',
				classcode : {
					name : 'No',
					method : {
						name : 'setPai(No)',
						lines : [42]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture2_2',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture2_3',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture2_3',
				classcode : {
					name : 'No',
					method : {
						name : 'setDireita(No)',
						lines : [66]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture2_3',
				classcode : {
					name : 'No',
					method : {
						name : 'setEsquerda(No)',
						lines : [54]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture2_3',
				classcode : {
					name : 'No',
					method : {
						name : 'setPai(No)',
						lines : [42]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture2_3',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setDireita(No)',
						lines : [66]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setEsquerda(No)',
						lines : [54]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setPai(No)',
						lines : [42]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture3_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture3_2',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture3_2',
				classcode : {
					name : 'No',
					method : {
						name : 'setDireita(No)',
						lines : [66]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture3_2',
				classcode : {
					name : 'No',
					method : {
						name : 'setEsquerda(No)',
						lines : [54]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture3_2',
				classcode : {
					name : 'No',
					method : {
						name : 'setPai(No)',
						lines : [42]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture3_2',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture3_3',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture3_3',
				classcode : {
					name : 'No',
					method : {
						name : 'setDireita(No)',
						lines : [66]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture3_3',
				classcode : {
					name : 'No',
					method : {
						name : 'setEsquerda(No)',
						lines : [54]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture3_3',
				classcode : {
					name : 'No',
					method : {
						name : 'setPai(No)',
						lines : [42]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture3_3',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setDireita(No)',
						lines : [66]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setEsquerda(No)',
						lines : [54]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setPai(No)',
						lines : [42]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture4_1',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture4_2',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture4_2',
				classcode : {
					name : 'No',
					method : {
						name : 'setDireita(No)',
						lines : [66]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture4_2',
				classcode : {
					name : 'No',
					method : {
						name : 'setEsquerda(No)',
						lines : [54]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture4_2',
				classcode : {
					name : 'No',
					method : {
						name : 'setPai(No)',
						lines : [42]
					}
				}
			}
		});
		suites.push({
			name : 'NoTest',
			testcase : {
				name: 'testSetAltura_fixture4_2',
				classcode : {
					name : 'No',
					method : {
						name : 'setAltura(int)',
						lines : [30]
					}
				}
			}
		});
	}

	return {
		getData : function (){
			return suites;
		},
		load : function (){
			init();
		}
	};
})();
