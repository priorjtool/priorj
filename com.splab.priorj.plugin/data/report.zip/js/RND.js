var rndTests = new Array();

$(function(){
	loadListRND();
});

function loadListRND(){
}

function getOrderRND(){
	return rndTests;
}

function getRNDPosition(testName){
	return rndTests[testName];
}
