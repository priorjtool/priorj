var rndTests = new Array();

$(function(){
	loadListRND();
});

function loadListRND(){
	rndTests['easyaccept.script.TestScript.testParameterPassingSyntax'] = 1;
	rndTests['easyaccept.script.TestExecuteScriptProcessor.testExecuteScriptProcessor'] = 2;
	rndTests['easyaccept.script.TestScript.testScript10'] = 3;
	rndTests['easyaccept.script.TestScript.testScript12'] = 4;
	rndTests['util.TestLogicalLineReader.testComment'] = 5;
	rndTests['easyaccept.script.TestScript.testScript6'] = 6;
	rndTests['easyaccept.script.TestScript.testExpectDifferent'] = 7;
	rndTests['util.TestLogicalLineReader.testLineWithSpacesReadByCharacter'] = 8;
	rndTests['easyaccept.script.TestScript.testScript4'] = 9;
	rndTests['easyaccept.script.TestStackTraceProcessor.testUnexpectedException'] = 10;
	rndTests['util.TestParameterTypeConverter.testConvertParam'] = 11;
	rndTests['easyaccept.script.TestScript.testScript7'] = 12;
	rndTests['easyaccept.script.TestScript.testScript5'] = 13;
	rndTests['easyaccept.script.TestQuitProcessor.testExecute'] = 14;
	rndTests['easyaccept.script.TestExpectErrorProcessor.testExecute'] = 15;
	rndTests['easyaccept.script.TestScript.testMethodMatch'] = 16;
	rndTests['easyaccept.script.TestScript.testScript11'] = 17;
	rndTests['util.TestLogicalLineReader.testUnread'] = 18;
	rndTests['util.TestLogicalLineReader.testMixedRead'] = 19;
	rndTests['easyaccept.script.TestExpectWithinProcessor.testWithin1'] = 20;
	rndTests['easyaccept.script.TestScript.testScript8'] = 21;
	rndTests['util.TestLogicalLineReader.testLineWithSpaces'] = 22;
	rndTests['util.TestLogicalLineReader.testSimpleFile'] = 23;
	rndTests['util.TestLogicalLineReader.testBackSlashRemains'] = 24;
	rndTests['easyaccept.script.TestScript.testScript1'] = 25;
	rndTests['easyaccept.script.TestEqualFilesProcessor.testExecute'] = 26;
	rndTests['util.TestLogicalLineReader.testRead'] = 27;
	rndTests['easyaccept.script.TestScript.testScript9'] = 28;
	rndTests['easyaccept.script.TestScript.testScript3'] = 29;
	rndTests['easyaccept.script.TestScript.testScript2'] = 30;
	rndTests['easyaccept.script.TestStackTraceProcessor.testUnexpectedException'] = 31;
}

function getOrderRND(){
	return rndTests;
}

function getRNDPosition(testName){
	return rndTests[testName];
}
