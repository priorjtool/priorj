var rndTests = new Array();

/**
* Main function
*/
$(function(){
	loadListRND();
});

/**
* Loading the list.
*/
function loadListRND(){

}

/**
* Accessing the Test List.
*
*/
function getOrderRND(){
	return rndTests;
}
