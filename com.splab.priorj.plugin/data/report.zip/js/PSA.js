var psaTests = new Array();

$(function(){
	loadListPSA();
});

function loadListPSA(){
}

function getOrderPSA(){
	return psaTests;
}

function getPSAPosition(testName){
	return psaTests[testName];
}
