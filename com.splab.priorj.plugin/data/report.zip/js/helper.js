// Author : Samuel T. C. Santos
// Helper to Compute APFD Values
// 
// Module Helper
// @see { http://samueltcsantos.github.io/priorj }

var Helper = (function (){
	var failures = [];
	var changeList = [];
	var coverage = [];
	var apdfEntries = [];
	var orderAMC = [];
	var orderASC = [];
	var orderCB = [];
	var orderRND = [];
	var orderTMC = [];
	var orderTSC = [];
	var orderPST = [];
	var orderPSA = [];


	function failuresNumber(){
		return failures.length;
	}

	function faultsNumber(){
		return apfdEntries.length;
	}

	function computeAPFDValue(technique){
		var m = M();
		var n = N();
		var tfis = computeTFiValues(technique);

		APFD.setM(m);
		APFD.setN(n);
		APFD.setTfis(tfis);
		var value = APFD.computeValue();
		return value;
	}

	function computeTFiValues(technique){
		var tfis = [];
		apfdEntries.forEach(function(entry) {
		    tfis.push(minIndexIn(technique, entry.tests));
		});
		return tfis;
	}

	function serieTo(technique){
		return plotable(technique);
	}

	function plotable(technique){
	  var plotEntries = [];
	  
	  var n = N();
	  var m = M();

	  for (var i=0; i< failures.length; i++){
	    var x = indexIn(technique, failures[i]);
	    var px = Util.percentage(x,n);
	    var y = faultsTo(failures[i]);
	   
	    var py = Util.percentage(y, m);
	     
	    var plot = {
	      test : failures[i],
	      'px' : parseFloat(px),
	      'py' : parseFloat(py)
	    };

    	plotEntries.push(plot);
	  }
	  
	  plotEntries.sort(function(a, b) {return a.px - b.px;});
	  
	  var serie = [[0,0]];
	  
	  var cache = plotEntries[0].py;
	  
	  plotEntries.forEach(function (entry){
	    
	    var xi = entry.px;
	    var yi = entry.py;
	    
	    if ( yi < cache ){
	      if (!isDuplicated(serie,[xi, cache]))
	      	serie.push([xi, cache]);
	    }
	    else{
	      cache = yi;
	      if (!isDuplicated(serie, [xi,yi]))           
	      	serie.push([xi,yi]);             
	    }
	  });
	  serie.push([100,100]);
	  return serie;
	}



  function isDuplicated(serie, entry){
  	for (var i=0; i<serie.length; i++){
  		var current = serie[i];
  		if (current[0]== entry[0] && current[1]==entry[1]){
  			return true;
  		}
  	}
  	return false;
  }

	function faultsTo(test){
	  var counter = 0;
	  apfdEntries.forEach(function(entry){
	    if (Util.contains(entry.tests, test)){
	      counter++;
	    }
	  });
	  return counter;
	}

/*
	function serieTo(technique){
		var serie = [];
		
		var m = M(); //faults add by user number
		var f = failuresNumber(); //failed tests number 

		var y = getIndexAxisY(technique);
		
		var	x = getIndexAxisX(technique);
		
		if (y.length == x.length){
			for (var i=0; i<x.length;i++){
				serie.push([x[i],y[i]]);
			}
		}
		return serie;
	}
*/

	function getIndexAxisY(){
	  n = M();
	  var pa = []; //arithmetical progression
	  if (n>0){
		  var r = parseInt(100 / n);
		  var term = 0;
		  pa.push(term);
		  for (var i=0; i<n; i++){
		     term += r;
		     pa.push(term);
		  }
	  }
	  if (n % 100 !== 0){
	  	pa.push(100);
	  }
	  return pa;
	}

	function getIndexAxisX(technique){
		var n = N();
		var points = [];
		var x = 0;
		points.push(0);
		if(n > 0){
			failures.forEach(function(failure){
				var index = indexIn(technique, failure);
				x = parseInt(index * 100 / n);
				if(!Util.contains(points, x)){
					points.push(x);
				}
			});
		}
		points.push(100);
		//sorting
		points.sort(increase);	
		return points;
	}

	var increase = function(a, b){
	  return a-b;
	}; 

	function M(){
		return Object.keys(apfdEntries).length;
	}

	function N(){
		var n=0;
		if(hasThisTechnique('amc')){
			n = Object.keys(orderAMC).length;
		}
		else if (hasThisTechnique('asc')){
			n = Object.keys(orderASC).length;
		}
		else if (hasThisTechnique('cb')){
			n = Object.keys(orderCB).length;	
		}
		else if (hasThisTechnique('rnd')){
			n = Object.keys(orderRND).length;	
		}
		else if (hasThisTechnique('tmc')){
			n = Object.keys(orderTMC).length;	
		}
		else if (hasThisTechnique('tsc')){
			n = Object.keys(orderTSC).length;	
		}
		else if (hasThisTechnique('pst')){
			n = Object.keys(orderPST).length;
		}
		else if (hasThisTechnique('psa')){
			n = Object.keys(orderPSA).length;
		}
		return n;
	}

	function minIndexIn(technique, tests){
		var indexMin = indexIn(technique, tests[0]);
		for (var i=1; i < tests.length; i++){
			var currentIndex = indexIn(technique, tests[i]);
			if ( currentIndex < indexMin){
				indexMin = currentIndex;
			}
		}
		return indexMin;
	}

	function f1Measure(){
		var f1 = [];

		if (failuresNumber() > 0){

			if (hasThisTechnique('amc')){
				var obj = measure('amc', 'Additional Method Coverage');
				f1.push(obj);
			}
			if (hasThisTechnique('asc')){
				var obj = measure('asc', 'Additional Statement Coverage');
				f1.push(obj);
			}
			if (hasThisTechnique('tmc')){
				var obj = measure('tmc', 'Total Method Coverage');
				f1.push(obj);
			}
			if (hasThisTechnique('tsc')){
				var obj = measure('tsc', 'Total Statement Coverage');
				f1.push(obj);
			}
			if (hasThisTechnique('cb')){
				var obj = measure('cb', 'Changed Blocks');
				f1.push(obj);
			}
			if (hasThisTechnique('rnd')){
				var obj = measure('rnd', 'Random');
				f1.push(obj);
			}
			if (hasThisTechnique('pst')){
				var obj = measure('pst', 'Proposal Statement Total');
				f1.push(obj);
			}
			if (hasThisTechnique('psa')){
				var obj = measure('psa', 'Proposal Statement Additional');
				f1.push(obj);
			}
	  }
	  return f1;
	}
	
	function adaptedF1Measure(){
		var f1adapted = [];

		if (failuresNumber() > 0){

			if (hasThisTechnique('amc')){
				var obj = {
					key : 'amc',
					value : measureAdaptedTest('amc')
				}
				f1adapted.push(obj);
			}
			if (hasThisTechnique('asc')){
				var obj = {
					key : 'asc',
					value : measureAdaptedTest('asc')
				}
				f1adapted.push(obj);
			}
			if (hasThisTechnique('tmc')){
				var obj = {
					key : 'tmc',
					value : measureAdaptedTest('tmc')
				}
				f1adapted.push(obj);
			}
			if (hasThisTechnique('tsc')){
				var obj = {
					key : 'tsc',
					value : measureAdaptedTest('tsc')
				}
				f1adapted.push(obj);
			}
			if (hasThisTechnique('cb')){
				var obj = {
					key : 'cb',
					value : measureAdaptedTest('cb')
				}
				f1adapted.push(obj);
			}
			if (hasThisTechnique('rnd')){
				var obj = {
					key: 'rnd',
					value : measureAdaptedTest('rnd')
				}
				f1adapted.push(obj);
			}
			if (hasThisTechnique('pst')){
				var obj = { 
						key : 'pst',
						value : measureAdaptedTest('pst')
					}
				f1adapted.push(obj);
			}
			if (hasThisTechnique('psa')){
				var obj = {
					key : 'psa',
					value : measureAdaptedTest('psa')
				}
				f1adapted.push(obj);
			}
	  }
	  return f1adapted;
	}

    function measureAdaptedTest(techniqueId) {
        var failureCoverages = [];
        var failures = getFailures();
        for(f in failures){
            for (var i = 0; i < coverage.length; i++) {
                var tcName = coverage[i].testsuite + '.' + coverage[i].testcase;
                if(failures[f] == tcName) {
                    var list = coverage[i].changesCovered;
                    failureCoverages.push(
                        {
                            testCase: failures[f],
                            changeList: list
                        }
                    );

                }
            }
        }
        var changes = getChangeList();
        var sortedList = getSortedList(techniqueId);
        var objAdaptedMeasure = [];
        for (c in changes) {
            for (obj in failureCoverages) {
                var fail = failureCoverages[obj];
                if(Util.contains( fail.changeList, changes[c])) {
                    objAdaptedMeasure.push(
                        {
                            testCase: fail.testCase,
                            change: changes[c],
                            sortedPosition: sortedList[fail.testCase]
                        }
                    );
                }
            }
        }
		var result = minIndexInAdaptedList(objAdaptedMeasure);
        return result;
    }

	function minIndexInAdaptedList(adaptedList) {
		var result = [];
		for (index in adaptedList) {
			var change = adaptedList[index];
			var objIndex = Util.containsObjectAdapted(result, change);
			if (objIndex > -1) {
				if(change.sortedPosition < result[objIndex].sortedPosition) {
					result[objIndex].sortedPosition = change.sortedPosition;
					result[objIndex].testCase = change.testCase;
				}
			} else {
				result.push(change);
			}
		}
		return result;
	}

	function measure(techniqueId, techniqueName){
		var objF1 = {
					 name : techniqueName,
					 value : minIndexIn(techniqueId, failures)
				}
		return objF1;
	}
	
	function measureAdapted(techniqueId) {
		var objF1Adapted = [];
		for (var i = 0; i < changeList.length; i++) {
			var index = firstOccurrenceInSortedList(techniqueId, changeList[i]);
			if (index != -1) {
				objF1Adapted[i] = {
					name: changeList[i],
					value: index
				}
			}
		}
        measureAdaptedTest(techniqueId);
		return objF1Adapted;
	}
	
	function firstOccurrenceInSortedList(technique, change) {
		var sortedList = getSortedList(technique);
		if(sortedList != -1) {
			for ( test in sortedList) {
				var changes = getTestCaseCoverageChanges(test)
				if(changes.indexOf(change) > -1) {
					return sortedList[test];
				}
			}
		}
		return -1;
	}
	
	function getTestCaseCoverageChanges(testCaseName) {
		for (var i = 0; i < coverage.length; i++) {
			var tcName = coverage[i].testsuite + '.' + coverage[i].testcase;
            if(testCaseName == tcName) {
				return coverage[i].changesCovered;
			}
		}
		return [];
	}
	
	function getSortedList(technique) {
		switch (technique){
			case 'amc':
				return orderAMC;
				break;
			case 'asc':
				return orderASC;
				break;
			case 'cb':
				return orderCB;
				break;
			case 'rnd':
				return orderRND;
				break;
			case 'tmc':
				return orderTMC;
				break;
			case 'tsc':
				return orderTSC;
				break;
			case 'pst':
				return orderPST;
				break;
			case 'psa':
				return orderPSA;
				break;
			default:
				return -1;
				break;
		}
	}
	
	function indexIn(technique, test){
		switch (technique){
			case 'amc':
				return orderAMC[test];
				break;
			case 'asc':
				return orderASC[test];
				break;
			case 'cb':
				return orderCB[test];
				break;
			case 'rnd':
				return orderRND[test];
				break;
			case 'tmc':
				return orderTMC[test];
				break;
			case 'tsc':
				return orderTSC[test];
				break;
			case 'pst':
				return orderPST[test];
				break;
			case 'psa':
				return orderPSA[test];
				break;
			default:
				return -1;
				break;
		}
	}

	function setOrderPrior(technique, order){
		switch(technique){
			case 'amc':
				orderAMC = order;
				break;
			case 'asc':
				orderASC = order;
				break;
			case 'cb':
				orderCB = order;
				break;
			case 'rnd':
				orderRND = order;
				break;
			case 'tmc':
				orderTMC = order;
				break;
			case 'tsc':
				orderTSC = order;
				break;
			case 'pst':
				orderPST = order;
				break;
			case 'psa':
				orderPSA = order;
				break;
			default:
				break;
		}
	}

	function hasThisTechnique(technique){
		switch(technique){
			case 'amc':
				return Object.keys(orderAMC).length > 0;
				break;
			case 'asc':
				return Object.keys(orderASC).length > 0;
				break;
			case 'cb':
				return Object.keys(orderCB).length > 0;
				break; 
			case 'rnd':
				return Object.keys(orderRND).length > 0;
				break;
			case 'tmc':
				return Object.keys(orderTMC).length > 0;
				break;
			case 'tsc':
				return Object.keys(orderTSC).length > 0;
				break;
			case 'pst':
				return Object.keys(orderPST).length > 0;
				break;
			case 'psa':
				return Object.keys(orderPSA).length > 0;
				break;
			default:
				return false;
				break;
		}
	}

	return {
		setFailures : function (failuresList){
			failures = failuresList;
		},
		setCoverage : function (coverageList) {
			coverage = coverageList;
		},
		setChangeList : function (changes){
			changeList = changes;
		},
		setAPFDEntries : function (entries){
			apfdEntries = entries;
		},
		setOrder : function (technique, order){
			setOrderPrior(technique, order);
		},
		getFailuresNumber : function(){
			return failuresNumber();
		},
		getFaultsNumber : function (){
			return faultsNumber();
		},
		has : function (technique){
			return hasThisTechnique(technique);
		},
		getIndex : function(technique, test){
			return indexIn(technique,test);
		},
		getAPFDValue: function(technique) {
			return computeAPFDValue(technique);
		},
		minIndexFrom : function (technique, tests){
			return minIndexIn(technique,tests);
		},
		getTFis : function (technique){
			return computeTFiValues(technique);
		},
		getN : function(){
			return N();
		},
		getM : function (){
			return M();
		},
		getSerie : function (technique){
			return serieTo(technique);
		},
		getAxisX : function (technique){
			return getIndexAxisX(technique);
		},
		getAxisY : function(technique){
			return getIndexAxisY(technique);
		},
		getF1Measure : function(){
			return f1Measure();
		},
		getF1MeasureAdapted : function(){
			return adaptedF1Measure();
		}
	};
})();

