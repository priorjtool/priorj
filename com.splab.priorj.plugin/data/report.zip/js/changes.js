var changeList = new Array();

$(function(){
	loadChangeList();
});

function loadChangeList(){
}

function getChangeList(){
	return changeList;
}
