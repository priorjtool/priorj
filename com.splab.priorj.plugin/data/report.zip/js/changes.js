var changeList = new Array();

/**
* Main function
*/
$(function(){
	loadChangeList();
});

/**
* Loading the list.
*/
function loadChangeList(){

}

/**
* Accessing the Test List.
*
*/
function getChangeList(){
	return changeList;
}