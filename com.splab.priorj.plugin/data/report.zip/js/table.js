

var TableApp = (function(){

    var datatable = null;
    var failures = null;

    function fillTable(){
   
        $("#tree").append('<tbody>');  
        
        datatable.forEach(function(entry){
            var row = '';
            var tRow = ''
            if(contains(failures, entry.testcase.name)){
                tRow = '<tr class="danger">';
            }
            else {
                tRow = '<tr class="success">';
            }
            row += '<td>' + entry.name + '</td>';
            row += '<td>' + entry.testcase.name +'</td>';
            row += '<td>' + entry.testcase.classcode.name +'</td>';
            row += '<td>' + entry.testcase.classcode.method.name +'</td>';
            
            var lines = entry.testcase.classcode.method.lines;
            var numbers = '';
            
            lines.forEach(function(number){
                numbers += number + ', ';
            });
            
            row += '<td>' + numbers +'</td>';
            $("#tree").append(tRow + row + '</tr>');
              
        });
        $("#tree").append('</tbody>');  
    }

    
    function contains(list, element){
        var found = false;
        list.forEach(function(item){
            if(item.indexOf(element) > -1){
                found = true;
            }
        });
        return found;
    }
    
    return {
        fill : function (){
            fillTable();
        },
        setData : function (data){
            datatable = data;
        },
        setFailures : function (failuresList){
            failures = failuresList;
        }
    }

})();

/*
* Please consider that the JS part isn't production ready at all, 
* I just code it to show the concept of merging filters 
* and titles together !
*/
$(document).ready(function(){

    treeData.load();
    var data = treeData.getData();

    //loadFailuresList();
    var failures = getFailures();
    
    TableApp.setFailures(failures);

    TableApp.setData(data);

    TableApp.fill();

    $('.filterable .btn-filter').click(function(){
        var $panel = $(this).parents('.filterable'),
        $filters = $panel.find('.filters input'),
        $tbody = $panel.find('.table tbody');
        if ($filters.prop('disabled') == true) {
            $filters.prop('disabled', false);
            $filters.first().focus();
        } else {
            $filters.val('').prop('disabled', true);
            $tbody.find('.no-result').remove();
            $tbody.find('tr').show();
        }
    });

    $('.filterable .filters input').keyup(function(e){
        /* Ignore tab key */
        var code = e.keyCode || e.which;
        if (code == '9') return;
        /* Useful DOM data and selectors */
        var $input = $(this),
        inputContent = $input.val().toLowerCase(),
        $panel = $input.parents('.filterable'),
        column = $panel.find('.filters th').index($input.parents('th')),
        $table = $panel.find('.table'),
        $rows = $table.find('tbody tr');
        /* Dirtiest filter function ever ;) */
        var $filteredRows = $rows.filter(function(){
            var value = $(this).find('td').eq(column).text().toLowerCase();
            return value.indexOf(inputContent) === -1;
        });
        /* Clean previous no-result if exist */
        $table.find('tbody .no-result').remove();
        /* Show all rows, hide filtered ones (never do that outside of a demo ! xD) */
        $rows.show();
        $filteredRows.hide();
        /* Prepend no-result row if all rows are filtered */
        if ($filteredRows.length === $rows.length) {
            $table.find('tbody').prepend($('<tr class="no-result text-center"><td colspan="'+ $table.find('.filters th').length +'">No result found</td></tr>'));
        }
    });
});

