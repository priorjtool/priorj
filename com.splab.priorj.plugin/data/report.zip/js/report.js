var coverage = [];

var coverageGlobal = {
	suites: 3,
	testcases: 66,
	classes: 2,
	methods: 16,
	statements: 22,
	changesCovered: ['avl.AVLImpl.percorrePreOrdem().29','avl.AVLImpl.percorrePosOrdem().37']
};

$(function(){
	loadData();
});

function loadData(){
	coverage.push({
		testsuite  : 'tests.ArvoreAVLTest',
		testcase   : 'testGetRaiz_fixture_1',
		classes    : 1,
		methods    : 1,
		statements : 2,
		changesCovered : ['avl.AVLImpl.getRaiz().12','avl.AVLImpl.getRaiz().14']
	});
	coverage.push({
		testsuite  : 'tests.ArvoreAVLTest',
		testcase   : 'testInserir_fixture_1',
		classes    : 1,
		methods    : 3,
		statements : 7,
		changesCovered : ['avl.AVLImpl.inserir(int).45','avl.AVLImpl.pesquisar(int).69','avl.AVLImpl.pesquisarNo(No, int).370','avl.AVLImpl.pesquisarNo(No, int).372','avl.AVLImpl.pesquisarNo(No, int).50','avl.AVLImpl.pesquisarNo(No, int).52','avl.AVLImpl.pesquisarNo(No, int).54']
	});
	coverage.push({
		testsuite  : 'tests.ArvoreAVLTest',
		testcase   : 'testInserir_fixture_2',
		classes    : 1,
		methods    : 3,
		statements : 7,
		changesCovered : ['avl.AVLImpl.inserir(int).45','avl.AVLImpl.pesquisar(int).69','avl.AVLImpl.pesquisarNo(No, int).370','avl.AVLImpl.pesquisarNo(No, int).372','avl.AVLImpl.pesquisarNo(No, int).50','avl.AVLImpl.pesquisarNo(No, int).52','avl.AVLImpl.pesquisarNo(No, int).54']
	});
	coverage.push({
		testsuite  : 'tests.ArvoreAVLTest',
		testcase   : 'testInserir_fixture_3',
		classes    : 1,
		methods    : 3,
		statements : 7,
		changesCovered : ['avl.AVLImpl.inserir(int).45','avl.AVLImpl.pesquisar(int).69','avl.AVLImpl.pesquisarNo(No, int).370','avl.AVLImpl.pesquisarNo(No, int).372','avl.AVLImpl.pesquisarNo(No, int).50','avl.AVLImpl.pesquisarNo(No, int).52','avl.AVLImpl.pesquisarNo(No, int).54']
	});
	coverage.push({
		testsuite  : 'tests.ArvoreAVLTest',
		testcase   : 'testGetAltura_fixture_1',
		classes    : 1,
		methods    : 1,
		statements : 1,
		changesCovered : ['avl.AVLImpl.getAltura(No).23']
	});
	coverage.push({
		testsuite  : 'tests.ArvoreAVLTest',
		testcase   : 'testPercorrePreOrdem_fixture_1',
		classes    : 1,
		methods    : 1,
		statements : 1,
		changesCovered : ['avl.AVLImpl.percorrePreOrdem().29']
	});
	coverage.push({
		testsuite  : 'tests.ArvoreAVLTest',
		testcase   : 'testPesquisar_fixture_1',
		classes    : 1,
		methods    : 2,
		statements : 3,
		changesCovered : ['avl.AVLImpl.pesquisar(int).69','avl.AVLImpl.pesquisarNo(No, int).370','avl.AVLImpl.pesquisarNo(No, int).372']
	});
	coverage.push({
		testsuite  : 'tests.ArvoreAVLTest',
		testcase   : 'testPesquisar_fixture_2',
		classes    : 1,
		methods    : 2,
		statements : 3,
		changesCovered : ['avl.AVLImpl.pesquisar(int).69','avl.AVLImpl.pesquisarNo(No, int).370','avl.AVLImpl.pesquisarNo(No, int).372']
	});
	coverage.push({
		testsuite  : 'tests.ArvoreAVLTest',
		testcase   : 'testPesquisar_fixture_3',
		classes    : 1,
		methods    : 2,
		statements : 3,
		changesCovered : ['avl.AVLImpl.pesquisar(int).69','avl.AVLImpl.pesquisarNo(No, int).370','avl.AVLImpl.pesquisarNo(No, int).372']
	});
	coverage.push({
		testsuite  : 'tests.ArvoreAVLTest',
		testcase   : 'testPercorrePosOrdem_fixture_1',
		classes    : 1,
		methods    : 1,
		statements : 1,
		changesCovered : ['avl.AVLImpl.percorrePosOrdem().37']
	});
	coverage.push({
		testsuite  : 'tests.ArvoreAVLTest',
		testcase   : 'testGetRaiz_fixture_1',
		classes    : 1,
		methods    : 1,
		statements : 2,
		changesCovered : ['avl.AVLImpl.getRaiz().12','avl.AVLImpl.getRaiz().14']
	});
	coverage.push({
		testsuite  : 'tests.AVLImplTest',
		testcase   : 'testSetAltura_fixture4_3',
		classes    : 1,
		methods    : 4,
		statements : 4,
		changesCovered : ['avl.No.setAltura(int).30','avl.No.setDireita(No).66','avl.No.setEsquerda(No).54','avl.No.setPai(No).42','avl.No.setAltura(int).30']
	});
	coverage.push({
		testsuite  : 'tests.AVLImplTest',
		testcase   : 'testInserir_fixture_1',
		classes    : 1,
		methods    : 1,
		statements : 2,
		changesCovered : ['avl.AVLImpl.inserir(int).45','avl.AVLImpl.inserir(int).47']
	});
	coverage.push({
		testsuite  : 'tests.AVLImplTest',
		testcase   : 'testInserir_fixture_2',
		classes    : 1,
		methods    : 3,
		statements : 7,
		changesCovered : ['avl.AVLImpl.inserir(int).45','avl.AVLImpl.pesquisar(int).69','avl.AVLImpl.pesquisarNo(No, int).370','avl.AVLImpl.pesquisarNo(No, int).372','avl.AVLImpl.pesquisarNo(No, int).50','avl.AVLImpl.pesquisarNo(No, int).52','avl.AVLImpl.pesquisarNo(No, int).54']
	});
	coverage.push({
		testsuite  : 'tests.AVLImplTest',
		testcase   : 'testGetAltura_fixture_1',
		classes    : 1,
		methods    : 1,
		statements : 1,
		changesCovered : ['avl.AVLImpl.getAltura(No).23']
	});
	coverage.push({
		testsuite  : 'tests.AVLImplTest',
		testcase   : 'testPercorrePreOrdem_fixture_1',
		classes    : 1,
		methods    : 1,
		statements : 1,
		changesCovered : ['avl.AVLImpl.percorrePreOrdem().29']
	});
	coverage.push({
		testsuite  : 'tests.AVLImplTest',
		testcase   : 'testPesquisar_fixture_1',
		classes    : 1,
		methods    : 2,
		statements : 3,
		changesCovered : ['avl.AVLImpl.pesquisar(int).69','avl.AVLImpl.pesquisarNo(No, int).370','avl.AVLImpl.pesquisarNo(No, int).372']
	});
	coverage.push({
		testsuite  : 'tests.AVLImplTest',
		testcase   : 'testPesquisar_fixture_2',
		classes    : 1,
		methods    : 2,
		statements : 3,
		changesCovered : ['avl.AVLImpl.pesquisar(int).69','avl.AVLImpl.pesquisarNo(No, int).370','avl.AVLImpl.pesquisarNo(No, int).372']
	});
	coverage.push({
		testsuite  : 'tests.AVLImplTest',
		testcase   : 'testPesquisar_fixture_3',
		classes    : 1,
		methods    : 2,
		statements : 3,
		changesCovered : ['avl.AVLImpl.pesquisar(int).69','avl.AVLImpl.pesquisarNo(No, int).370','avl.AVLImpl.pesquisarNo(No, int).372']
	});
	coverage.push({
		testsuite  : 'tests.AVLImplTest',
		testcase   : 'testPercorrePosOrdem_fixture_1',
		classes    : 1,
		methods    : 1,
		statements : 1,
		changesCovered : ['avl.AVLImpl.percorrePosOrdem().37']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testGetPai_fixture1_1',
		classes    : 1,
		methods    : 1,
		statements : 1,
		changesCovered : ['avl.No.getPai().36']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testGetPai_fixture2_1',
		classes    : 1,
		methods    : 9,
		statements : 9,
		changesCovered : ['avl.No.setAltura(int).30','avl.No.setDireita(No).66','avl.No.setEsquerda(No).54','avl.No.setPai(No).42','avl.No.getPai().36','avl.No.getAltura().24','avl.No.getPai().36','avl.No.getValor().18','avl.No.getDireita().60','avl.No.getEsquerda().48']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testGetPai_fixture3_1',
		classes    : 1,
		methods    : 9,
		statements : 9,
		changesCovered : ['avl.No.setAltura(int).30','avl.No.setDireita(No).66','avl.No.setEsquerda(No).54','avl.No.setPai(No).42','avl.No.getPai().36','avl.No.getAltura().24','avl.No.getPai().36','avl.No.getValor().18','avl.No.getDireita().60','avl.No.getEsquerda().48']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testGetPai_fixture4_1',
		classes    : 1,
		methods    : 9,
		statements : 9,
		changesCovered : ['avl.No.setAltura(int).30','avl.No.setDireita(No).66','avl.No.setEsquerda(No).54','avl.No.setPai(No).42','avl.No.getPai().36','avl.No.getAltura().24','avl.No.getPai().36','avl.No.getValor().18','avl.No.getDireita().60','avl.No.getEsquerda().48']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testGetAltura_fixture1_1',
		classes    : 1,
		methods    : 1,
		statements : 1,
		changesCovered : ['avl.No.getAltura().24']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testGetAltura_fixture2_1',
		classes    : 1,
		methods    : 5,
		statements : 5,
		changesCovered : ['avl.No.setAltura(int).30','avl.No.setDireita(No).66','avl.No.setEsquerda(No).54','avl.No.setPai(No).42','avl.No.getAltura().24']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testGetAltura_fixture3_1',
		classes    : 1,
		methods    : 5,
		statements : 5,
		changesCovered : ['avl.No.setAltura(int).30','avl.No.setDireita(No).66','avl.No.setEsquerda(No).54','avl.No.setPai(No).42','avl.No.getAltura().24']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testGetAltura_fixture4_1',
		classes    : 1,
		methods    : 5,
		statements : 5,
		changesCovered : ['avl.No.setAltura(int).30','avl.No.setDireita(No).66','avl.No.setEsquerda(No).54','avl.No.setPai(No).42','avl.No.getAltura().24']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testNo_1',
		classes    : 1,
		methods    : 5,
		statements : 5,
		changesCovered : ['avl.No.getAltura().24','avl.No.getPai().36','avl.No.getValor().18','avl.No.getDireita().60','avl.No.getEsquerda().48']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testNo_2',
		classes    : 1,
		methods    : 5,
		statements : 5,
		changesCovered : ['avl.No.getAltura().24','avl.No.getPai().36','avl.No.getValor().18','avl.No.getDireita().60','avl.No.getEsquerda().48']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testNo_3',
		classes    : 1,
		methods    : 5,
		statements : 5,
		changesCovered : ['avl.No.getAltura().24','avl.No.getPai().36','avl.No.getValor().18','avl.No.getDireita().60','avl.No.getEsquerda().48']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testSetEsquerda_fixture1_1',
		classes    : 1,
		methods    : 1,
		statements : 1,
		changesCovered : ['avl.No.setEsquerda(No).54']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testSetEsquerda_fixture2_1',
		classes    : 1,
		methods    : 4,
		statements : 4,
		changesCovered : ['avl.No.setAltura(int).30','avl.No.setDireita(No).66','avl.No.setEsquerda(No).54','avl.No.setPai(No).42','avl.No.setEsquerda(No).54']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testSetEsquerda_fixture3_1',
		classes    : 1,
		methods    : 4,
		statements : 4,
		changesCovered : ['avl.No.setAltura(int).30','avl.No.setDireita(No).66','avl.No.setEsquerda(No).54','avl.No.setPai(No).42','avl.No.setEsquerda(No).54']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testSetEsquerda_fixture4_1',
		classes    : 1,
		methods    : 4,
		statements : 4,
		changesCovered : ['avl.No.setAltura(int).30','avl.No.setDireita(No).66','avl.No.setEsquerda(No).54','avl.No.setPai(No).42','avl.No.setEsquerda(No).54']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testSetDireita_fixture1_1',
		classes    : 1,
		methods    : 1,
		statements : 1,
		changesCovered : ['avl.No.setDireita(No).66']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testSetDireita_fixture2_1',
		classes    : 1,
		methods    : 4,
		statements : 4,
		changesCovered : ['avl.No.setAltura(int).30','avl.No.setDireita(No).66','avl.No.setEsquerda(No).54','avl.No.setPai(No).42','avl.No.setDireita(No).66']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testSetDireita_fixture3_1',
		classes    : 1,
		methods    : 4,
		statements : 4,
		changesCovered : ['avl.No.setAltura(int).30','avl.No.setDireita(No).66','avl.No.setEsquerda(No).54','avl.No.setPai(No).42','avl.No.setDireita(No).66']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testSetDireita_fixture4_1',
		classes    : 1,
		methods    : 4,
		statements : 4,
		changesCovered : ['avl.No.setAltura(int).30','avl.No.setDireita(No).66','avl.No.setEsquerda(No).54','avl.No.setPai(No).42','avl.No.setDireita(No).66']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testGetValor_fixture1_1',
		classes    : 1,
		methods    : 1,
		statements : 1,
		changesCovered : ['avl.No.getValor().18']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testGetValor_fixture2_1',
		classes    : 1,
		methods    : 5,
		statements : 5,
		changesCovered : ['avl.No.setAltura(int).30','avl.No.setDireita(No).66','avl.No.setEsquerda(No).54','avl.No.setPai(No).42','avl.No.getValor().18']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testGetValor_fixture3_1',
		classes    : 1,
		methods    : 5,
		statements : 5,
		changesCovered : ['avl.No.setAltura(int).30','avl.No.setDireita(No).66','avl.No.setEsquerda(No).54','avl.No.setPai(No).42','avl.No.getValor().18']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testGetValor_fixture4_1',
		classes    : 1,
		methods    : 5,
		statements : 5,
		changesCovered : ['avl.No.setAltura(int).30','avl.No.setDireita(No).66','avl.No.setEsquerda(No).54','avl.No.setPai(No).42','avl.No.getValor().18']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testGetDireita_fixture1_1',
		classes    : 1,
		methods    : 1,
		statements : 1,
		changesCovered : ['avl.No.getDireita().60']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testGetDireita_fixture2_1',
		classes    : 1,
		methods    : 9,
		statements : 9,
		changesCovered : ['avl.No.setAltura(int).30','avl.No.setDireita(No).66','avl.No.setEsquerda(No).54','avl.No.setPai(No).42','avl.No.getDireita().60','avl.No.getAltura().24','avl.No.getPai().36','avl.No.getValor().18','avl.No.getDireita().60','avl.No.getEsquerda().48']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testGetDireita_fixture3_1',
		classes    : 1,
		methods    : 9,
		statements : 9,
		changesCovered : ['avl.No.setAltura(int).30','avl.No.setDireita(No).66','avl.No.setEsquerda(No).54','avl.No.setPai(No).42','avl.No.getDireita().60','avl.No.getAltura().24','avl.No.getPai().36','avl.No.getValor().18','avl.No.getDireita().60','avl.No.getEsquerda().48']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testGetDireita_fixture4_1',
		classes    : 1,
		methods    : 9,
		statements : 9,
		changesCovered : ['avl.No.setAltura(int).30','avl.No.setDireita(No).66','avl.No.setEsquerda(No).54','avl.No.setPai(No).42','avl.No.getDireita().60','avl.No.getAltura().24','avl.No.getPai().36','avl.No.getValor().18','avl.No.getDireita().60','avl.No.getEsquerda().48']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testSetPai_fixture1_1',
		classes    : 1,
		methods    : 1,
		statements : 1,
		changesCovered : ['avl.No.setPai(No).42']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testSetPai_fixture2_1',
		classes    : 1,
		methods    : 4,
		statements : 4,
		changesCovered : ['avl.No.setAltura(int).30','avl.No.setDireita(No).66','avl.No.setEsquerda(No).54','avl.No.setPai(No).42','avl.No.setPai(No).42']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testSetPai_fixture3_1',
		classes    : 1,
		methods    : 4,
		statements : 4,
		changesCovered : ['avl.No.setAltura(int).30','avl.No.setDireita(No).66','avl.No.setEsquerda(No).54','avl.No.setPai(No).42','avl.No.setPai(No).42']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testSetPai_fixture4_1',
		classes    : 1,
		methods    : 4,
		statements : 4,
		changesCovered : ['avl.No.setAltura(int).30','avl.No.setDireita(No).66','avl.No.setEsquerda(No).54','avl.No.setPai(No).42','avl.No.setPai(No).42']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testGetEsquerda_fixture1_1',
		classes    : 1,
		methods    : 1,
		statements : 1,
		changesCovered : ['avl.No.getEsquerda().48']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testGetEsquerda_fixture2_1',
		classes    : 1,
		methods    : 9,
		statements : 9,
		changesCovered : ['avl.No.setAltura(int).30','avl.No.setDireita(No).66','avl.No.setEsquerda(No).54','avl.No.setPai(No).42','avl.No.getEsquerda().48','avl.No.getAltura().24','avl.No.getPai().36','avl.No.getValor().18','avl.No.getDireita().60','avl.No.getEsquerda().48']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testGetEsquerda_fixture3_1',
		classes    : 1,
		methods    : 9,
		statements : 9,
		changesCovered : ['avl.No.setAltura(int).30','avl.No.setDireita(No).66','avl.No.setEsquerda(No).54','avl.No.setPai(No).42','avl.No.getEsquerda().48','avl.No.getAltura().24','avl.No.getPai().36','avl.No.getValor().18','avl.No.getDireita().60','avl.No.getEsquerda().48']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testGetEsquerda_fixture4_1',
		classes    : 1,
		methods    : 9,
		statements : 9,
		changesCovered : ['avl.No.setAltura(int).30','avl.No.setDireita(No).66','avl.No.setEsquerda(No).54','avl.No.setPai(No).42','avl.No.getEsquerda().48','avl.No.getAltura().24','avl.No.getPai().36','avl.No.getValor().18','avl.No.getDireita().60','avl.No.getEsquerda().48']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testSetAltura_fixture1_1',
		classes    : 1,
		methods    : 1,
		statements : 1,
		changesCovered : ['avl.No.setAltura(int).30']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testSetAltura_fixture1_2',
		classes    : 1,
		methods    : 1,
		statements : 1,
		changesCovered : ['avl.No.setAltura(int).30']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testSetAltura_fixture1_3',
		classes    : 1,
		methods    : 1,
		statements : 1,
		changesCovered : ['avl.No.setAltura(int).30']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testSetAltura_fixture2_1',
		classes    : 1,
		methods    : 4,
		statements : 4,
		changesCovered : ['avl.No.setAltura(int).30','avl.No.setDireita(No).66','avl.No.setEsquerda(No).54','avl.No.setPai(No).42','avl.No.setAltura(int).30']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testSetAltura_fixture2_2',
		classes    : 1,
		methods    : 4,
		statements : 4,
		changesCovered : ['avl.No.setAltura(int).30','avl.No.setDireita(No).66','avl.No.setEsquerda(No).54','avl.No.setPai(No).42','avl.No.setAltura(int).30']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testSetAltura_fixture2_3',
		classes    : 1,
		methods    : 4,
		statements : 4,
		changesCovered : ['avl.No.setAltura(int).30','avl.No.setDireita(No).66','avl.No.setEsquerda(No).54','avl.No.setPai(No).42','avl.No.setAltura(int).30']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testSetAltura_fixture3_1',
		classes    : 1,
		methods    : 4,
		statements : 4,
		changesCovered : ['avl.No.setAltura(int).30','avl.No.setDireita(No).66','avl.No.setEsquerda(No).54','avl.No.setPai(No).42','avl.No.setAltura(int).30']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testSetAltura_fixture3_2',
		classes    : 1,
		methods    : 4,
		statements : 4,
		changesCovered : ['avl.No.setAltura(int).30','avl.No.setDireita(No).66','avl.No.setEsquerda(No).54','avl.No.setPai(No).42','avl.No.setAltura(int).30']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testSetAltura_fixture3_3',
		classes    : 1,
		methods    : 4,
		statements : 4,
		changesCovered : ['avl.No.setAltura(int).30','avl.No.setDireita(No).66','avl.No.setEsquerda(No).54','avl.No.setPai(No).42','avl.No.setAltura(int).30']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testSetAltura_fixture4_1',
		classes    : 1,
		methods    : 4,
		statements : 4,
		changesCovered : ['avl.No.setAltura(int).30','avl.No.setDireita(No).66','avl.No.setEsquerda(No).54','avl.No.setPai(No).42','avl.No.setAltura(int).30']
	});
	coverage.push({
		testsuite  : 'tests.NoTest',
		testcase   : 'testSetAltura_fixture4_2',
		classes    : 1,
		methods    : 4,
		statements : 4,
		changesCovered : ['avl.No.setAltura(int).30','avl.No.setDireita(No).66','avl.No.setEsquerda(No).54','avl.No.setPai(No).42','avl.No.setAltura(int).30']
	});
}

	function getCoverageReportData(){
		return coverage;
	}

	function getCoverageGlobalData(){
		return coverageGlobal;
	}

