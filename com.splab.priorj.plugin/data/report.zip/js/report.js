var coverage = [];

var coverageGlobal = {
	suites: 9,
	testcases: 31,
	classes: 29,
	methods: 118,
	statements: 561
};

$(function(){
	loadData();
});

function loadData(){
	coverage.push({
		testsuite  : 'easyaccept.script.TestExecuteScriptProcessor',
		testcase   : 'testExecute',
		classes    : 9,
		methods    : 36,
		statements : 183
	});
	coverage.push({
		testsuite  : 'easyaccept.script.TestExpectErrorProcessor',
		testcase   : 'testExecuteScriptProcessor',
		classes    : 15,
		methods    : 71,
		statements : 318
	});
	coverage.push({
		testsuite  : 'easyaccept.script.TestExpectWithinProcessor',
		testcase   : 'testExecute',
		classes    : 14,
		methods    : 51,
		statements : 251
	});
	coverage.push({
		testsuite  : 'easyaccept.script.TestQuitProcessor',
		testcase   : 'testWithin1',
		classes    : 11,
		methods    : 65,
		statements : 291
	});
	coverage.push({
		testsuite  : 'easyaccept.script.TestScript',
		testcase   : 'testExecute',
		classes    : 8,
		methods    : 33,
		statements : 156
	});
	coverage.push({
		testsuite  : 'easyaccept.script.TestScript',
		testcase   : 'testMethodMatch',
		classes    : 14,
		methods    : 64,
		statements : 276
	});
	coverage.push({
		testsuite  : 'easyaccept.script.TestScript',
		testcase   : 'testExpectDifferent',
		classes    : 11,
		methods    : 61,
		statements : 267
	});
	coverage.push({
		testsuite  : 'easyaccept.script.TestScript',
		testcase   : 'testParameterPassingSyntax',
		classes    : 14,
		methods    : 63,
		statements : 272
	});
	coverage.push({
		testsuite  : 'easyaccept.script.TestScript',
		testcase   : 'testScript10',
		classes    : 14,
		methods    : 68,
		statements : 302
	});
	coverage.push({
		testsuite  : 'easyaccept.script.TestScript',
		testcase   : 'testScript11',
		classes    : 14,
		methods    : 68,
		statements : 296
	});
	coverage.push({
		testsuite  : 'easyaccept.script.TestScript',
		testcase   : 'testScript12',
		classes    : 14,
		methods    : 64,
		statements : 278
	});
	coverage.push({
		testsuite  : 'easyaccept.script.TestScript',
		testcase   : 'testScript1',
		classes    : 6,
		methods    : 34,
		statements : 155
	});
	coverage.push({
		testsuite  : 'easyaccept.script.TestScript',
		testcase   : 'testScript2',
		classes    : 13,
		methods    : 59,
		statements : 266
	});
	coverage.push({
		testsuite  : 'easyaccept.script.TestScript',
		testcase   : 'testScript3',
		classes    : 14,
		methods    : 61,
		statements : 305
	});
	coverage.push({
		testsuite  : 'easyaccept.script.TestScript',
		testcase   : 'testScript4',
		classes    : 13,
		methods    : 59,
		statements : 285
	});
	coverage.push({
		testsuite  : 'easyaccept.script.TestScript',
		testcase   : 'testScript5',
		classes    : 14,
		methods    : 65,
		statements : 300
	});
	coverage.push({
		testsuite  : 'easyaccept.script.TestScript',
		testcase   : 'testScript6',
		classes    : 10,
		methods    : 58,
		statements : 251
	});
	coverage.push({
		testsuite  : 'easyaccept.script.TestScript',
		testcase   : 'testScript7',
		classes    : 16,
		methods    : 72,
		statements : 313
	});
	coverage.push({
		testsuite  : 'easyaccept.script.TestScript',
		testcase   : 'testScript8',
		classes    : 13,
		methods    : 71,
		statements : 287
	});
	coverage.push({
		testsuite  : 'easyaccept.script.TestStackTraceProcessor',
		testcase   : 'testScript9',
		classes    : 15,
		methods    : 66,
		statements : 317
	});
	coverage.push({
		testsuite  : 'easyaccept.script.TestStackTraceProcessor',
		testcase   : 'testUnexpectedException',
		classes    : 17,
		methods    : 73,
		statements : 347
	});
	coverage.push({
		testsuite  : 'util.TestLogicalLineReader',
		testcase   : 'testUnexpectedException',
		classes    : 17,
		methods    : 73,
		statements : 347
	});
	coverage.push({
		testsuite  : 'util.TestLogicalLineReader',
		testcase   : 'testSimpleFile',
		classes    : 3,
		methods    : 18,
		statements : 82
	});
	coverage.push({
		testsuite  : 'util.TestLogicalLineReader',
		testcase   : 'testBackSlashRemains',
		classes    : 3,
		methods    : 13,
		statements : 63
	});
	coverage.push({
		testsuite  : 'util.TestLogicalLineReader',
		testcase   : 'testRead',
		classes    : 3,
		methods    : 14,
		statements : 71
	});
	coverage.push({
		testsuite  : 'util.TestLogicalLineReader',
		testcase   : 'testLineWithSpaces',
		classes    : 3,
		methods    : 17,
		statements : 86
	});
	coverage.push({
		testsuite  : 'util.TestLogicalLineReader',
		testcase   : 'testLineWithSpacesReadByCharacter',
		classes    : 3,
		methods    : 17,
		statements : 91
	});
	coverage.push({
		testsuite  : 'util.TestLogicalLineReader',
		testcase   : 'testComment',
		classes    : 3,
		methods    : 17,
		statements : 90
	});
	coverage.push({
		testsuite  : 'util.TestLogicalLineReader',
		testcase   : 'testMixedRead',
		classes    : 3,
		methods    : 18,
		statements : 97
	});
	coverage.push({
		testsuite  : 'util.TestParameterTypeConverter',
		testcase   : 'testUnread',
		classes    : 3,
		methods    : 19,
		statements : 99
	});
	coverage.push({
		testsuite  : 'util.TestParameterTypeConverter',
		testcase   : 'testConvertParam',
		classes    : 2,
		methods    : 4,
		statements : 23
	});
}

	function getCoverageReportData(){
		return coverage;
	}

	function getCoverageGlobalData(){
		return coverageGlobal;
	}

