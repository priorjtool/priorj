var coverage = [];

var coverageGlobal = {
		suites: 0,
		testcases: 0,
		classes: 0,
		methods : 0,
		statements: 0
};

$(function(){
	loadData();
});

function loadData(){
	
}

function getCoverageReportData(){
	return coverage;
}

function getCoverageGlobalData(){
	return coverageGlobal;
}
