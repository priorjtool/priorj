var amcTests = new Array();

/**
* Main function
*/
$(function(){
	loadListAMC();
});

/**
* Loading the list.
*/
function loadListAMC(){
}

/**
* Accessing the Test List.
*
*/
function getOrderAMC(){
	return amcTests;
}
