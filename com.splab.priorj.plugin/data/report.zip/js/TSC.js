var tscTests = new Array();

/**
* Main function
*/
$(function(){
	loadListTSC();
});

/**
* Loading the list.
*/
function loadListTSC(){

}

/**
* Accessing the Test List.
*
*/
function getOrderTSC(){
	return tscTests;
}
