var cbTests = new Array();

$(function(){
	loadListCB();
});

function loadListCB(){
	cbTests['util.TestLogicalLineReader.testSimpleFile'] = 1;
	cbTests['util.TestLogicalLineReader.testRead'] = 2;
	cbTests['util.TestLogicalLineReader.testLineWithSpaces'] = 3;
	cbTests['util.TestLogicalLineReader.testBackSlashRemains'] = 4;
	cbTests['util.TestLogicalLineReader.testUnread'] = 5;
	cbTests['easyaccept.script.TestScript.testScript12'] = 6;
	cbTests['easyaccept.script.TestScript.testScript2'] = 7;
	cbTests['easyaccept.script.TestStackTraceProcessor.testUnexpectedException'] = 8;
	cbTests['easyaccept.script.TestScript.testScript9'] = 9;
	cbTests['easyaccept.script.TestScript.testScript6'] = 10;
	cbTests['easyaccept.script.TestScript.testExpectDifferent'] = 11;
	cbTests['easyaccept.script.TestExpectWithinProcessor.testWithin1'] = 12;
	cbTests['easyaccept.script.TestScript.testScript8'] = 13;
	cbTests['easyaccept.script.TestExpectErrorProcessor.testExecute'] = 14;
	cbTests['easyaccept.script.TestStackTraceProcessor.testUnexpectedException'] = 15;
	cbTests['easyaccept.script.TestEqualFilesProcessor.testExecute'] = 16;
	cbTests['util.TestLogicalLineReader.testMixedRead'] = 17;
	cbTests['easyaccept.script.TestScript.testScript4'] = 18;
	cbTests['easyaccept.script.TestScript.testMethodMatch'] = 19;
	cbTests['easyaccept.script.TestScript.testScript7'] = 20;
	cbTests['easyaccept.script.TestScript.testScript5'] = 21;
	cbTests['util.TestLogicalLineReader.testComment'] = 22;
	cbTests['easyaccept.script.TestScript.testParameterPassingSyntax'] = 23;
	cbTests['util.TestLogicalLineReader.testLineWithSpacesReadByCharacter'] = 24;
	cbTests['easyaccept.script.TestScript.testScript10'] = 25;
	cbTests['util.TestParameterTypeConverter.testConvertParam'] = 26;
	cbTests['easyaccept.script.TestQuitProcessor.testExecute'] = 27;
	cbTests['easyaccept.script.TestExecuteScriptProcessor.testExecuteScriptProcessor'] = 28;
	cbTests['easyaccept.script.TestScript.testScript11'] = 29;
	cbTests['easyaccept.script.TestScript.testScript3'] = 30;
	cbTests['easyaccept.script.TestScript.testScript1'] = 31;
}

function getOrderCB(){
	return cbTests;
}

function getCBPosition(testName){
	return cbTests[testName];
}
