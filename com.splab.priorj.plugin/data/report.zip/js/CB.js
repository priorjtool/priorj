var cbTests = new Array();

/**
* Main function
*/
$(function(){
	loadListCB();
});

/**
* Loading the list.
*/
function loadListCB(){
}

/**
* Accessing the Test List.
*
*/
function getOrderCB(){
	return cbTests;
}

function getCBPosition(testName){
	return cbTests[testName];
}
