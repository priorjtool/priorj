var ecTests = new Array();

/**
* Main function
*/
$(function(){
	loadListEC();
});

/**
* Loading the list.
*/
function loadListEC(){

}

/**
* Accessing the Test List.
*
*/
function getOrderEC(){
	return ecTests;
}
