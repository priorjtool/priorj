var ecTests = new Array();

$(function(){
	loadListEC();
});

function loadListEC(){
	ecTests['util.TestLogicalLineReader.testSimpleFile'] = 1;
	ecTests['util.TestLogicalLineReader.testRead'] = 2;
	ecTests['util.TestLogicalLineReader.testLineWithSpaces'] = 3;
	ecTests['util.TestLogicalLineReader.testBackSlashRemains'] = 4;
	ecTests['easyaccept.script.TestEqualFilesProcessor.testExecute'] = 5;
	ecTests['easyaccept.script.TestExecuteScriptProcessor.testExecuteScriptProcessor'] = 6;
	ecTests['easyaccept.script.TestExpectErrorProcessor.testExecute'] = 7;
	ecTests['easyaccept.script.TestExpectWithinProcessor.testWithin1'] = 8;
	ecTests['easyaccept.script.TestQuitProcessor.testExecute'] = 9;
	ecTests['easyaccept.script.TestScript.testMethodMatch'] = 10;
	ecTests['easyaccept.script.TestScript.testExpectDifferent'] = 11;
	ecTests['easyaccept.script.TestScript.testParameterPassingSyntax'] = 12;
	ecTests['easyaccept.script.TestScript.testScript10'] = 13;
	ecTests['easyaccept.script.TestScript.testScript11'] = 14;
	ecTests['easyaccept.script.TestScript.testScript12'] = 15;
	ecTests['easyaccept.script.TestScript.testScript1'] = 16;
	ecTests['easyaccept.script.TestScript.testScript2'] = 17;
	ecTests['easyaccept.script.TestScript.testScript3'] = 18;
	ecTests['easyaccept.script.TestScript.testScript4'] = 19;
	ecTests['easyaccept.script.TestScript.testScript5'] = 20;
	ecTests['easyaccept.script.TestScript.testScript6'] = 21;
	ecTests['easyaccept.script.TestScript.testScript7'] = 22;
	ecTests['easyaccept.script.TestScript.testScript8'] = 23;
	ecTests['easyaccept.script.TestScript.testScript9'] = 24;
	ecTests['easyaccept.script.TestStackTraceProcessor.testUnexpectedException'] = 25;
	ecTests['easyaccept.script.TestStackTraceProcessor.testUnexpectedException'] = 26;
	ecTests['util.TestLogicalLineReader.testLineWithSpacesReadByCharacter'] = 27;
	ecTests['util.TestLogicalLineReader.testComment'] = 28;
	ecTests['util.TestLogicalLineReader.testMixedRead'] = 29;
	ecTests['util.TestLogicalLineReader.testUnread'] = 30;
	ecTests['util.TestParameterTypeConverter.testConvertParam'] = 31;
}

function getOrderEC(){
	return ecTests;
}

function getECPosition(testName){
	return ecTests[testName];
}
