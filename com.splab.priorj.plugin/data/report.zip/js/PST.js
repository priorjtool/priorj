var pstTests = new Array();

$(function(){
	loadListPST();
});

function loadListPST(){
}

function getOrderPST(){
	return pstTests;
}

function getPSTPosition(testName){
	return pstTests[testName];
}
