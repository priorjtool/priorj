var tmcTests = new Array();

/**
* Main function
*/
$(function(){
	loadListTMC();
});

/**
* Loading the list.
*/
function loadListTMC(){

}

/**
* Accessing the Test List.
*
*/
function getOrderTMC(){
	return tmcTests;
}
