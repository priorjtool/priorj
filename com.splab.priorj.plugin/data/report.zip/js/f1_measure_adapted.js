
$(function(){

	Helper.setFailures(getFailures());
	Helper.setChangeList(getChangeList());
	Helper.setCoverage(getCoverageReportData());
	Helper.setOrder('amc', getOrderAMC());
	Helper.setOrder('asc', getOrderASC());
	Helper.setOrder('cb', getOrderCB());
	Helper.setOrder('rnd', getOrderRND());
	Helper.setOrder('tmc', getOrderTMC());
	Helper.setOrder('tsc', getOrderTSC());
	Helper.setOrder('ec', getOrderEC());
	Helper.getF1MeasureAdapted();
	listEchelonChanged();
	listChangedBlocks();
	listRandom();
	listTSC();
	listTMC();
	listASC();
	listAMC();
});

function listEchelonChanged() {
	var f1MeasureAdapted = Helper.getF1MeasureAdapted();
	var measureEC;
	for ( obj in f1MeasureAdapted) {
		if(f1MeasureAdapted[obj].key == 'ec') {
			measureEC = f1MeasureAdapted[obj].value;
		}
	}
	for ( obj in measureEC) {
		var item = measureEC[obj].name;
		var position = measureEC[obj].value;
		$('#f1adaptedEC').append('<li class="list-group-item list-group-item-info" title="'+item+'">' + item + '<span class="badge pull-right">'+position+'</span></li>');
	}
}

function listChangedBlocks() {
	var f1MeasureAdapted = Helper.getF1MeasureAdapted();
	var measureCB;
	for ( obj in f1MeasureAdapted) {
		if(f1MeasureAdapted[obj].key == 'cb') {
			measureCB = f1MeasureAdapted[obj].value;
		}
	}
	for ( obj in measureCB) {
		var item = measureCB[obj].name;
		var position = measureCB[obj].value;
		$('#f1adaptedCB').append('<li class="list-group-item list-group-item-info" title="'+item+'">' + item + '<span class="badge pull-right">'+position+'</span></li>');
	}
}

function listRandom() {
	var f1MeasureAdapted = Helper.getF1MeasureAdapted();
	var measureRND;
	for ( obj in f1MeasureAdapted) {
		if(f1MeasureAdapted[obj].key == 'rnd') {
			measureRND = f1MeasureAdapted[obj].value;
		}
	}
	for ( obj in measureRND) {
		var item = measureRND[obj].name;
		var position = measureRND[obj].value;
		$('#f1adaptedR').append('<li class="list-group-item list-group-item-info" title="'+item+'">' + item + '<span class="badge pull-right">'+position+'</span></li>');
	}
}

function listTSC() {
	var f1MeasureAdapted = Helper.getF1MeasureAdapted();
	var measureTSC;
	for ( obj in f1MeasureAdapted) {
		if(f1MeasureAdapted[obj].key == 'tsc') {
			measureTSC = f1MeasureAdapted[obj].value;
		}
	}
	for ( obj in measureTSC) {
		var item = measureTSC[obj].name;
		var position = measureTSC[obj].value;
		$('#f1adaptedTSC').append('<li class="list-group-item list-group-item-info" title="'+item+'">' + item + '<span class="badge pull-right">'+position+'</span></li>');
	}
}

function listTMC() {
	var f1MeasureAdapted = Helper.getF1MeasureAdapted();
	var measureTMC;
	for ( obj in f1MeasureAdapted) {
		if(f1MeasureAdapted[obj].key == 'tmc') {
			measureTMC = f1MeasureAdapted[obj].value;
		}
	}
	for ( obj in measureTMC) {
		var item = measureTMC[obj].name;
		var position = measureTMC[obj].value;
		$('#f1adaptedTMC').append('<li class="list-group-item list-group-item-info" title="'+item+'">' + item + '<span class="badge pull-right">'+position+'</span></li>');
	}
}

function listAMC() {
	var f1MeasureAdapted = Helper.getF1MeasureAdapted();
	var measureAMC;
	for ( obj in f1MeasureAdapted) {
		if(f1MeasureAdapted[obj].key == 'amc') {
			measureAMC = f1MeasureAdapted[obj].value;
		}
	}
	for ( obj in measureAMC) {
		var item = measureAMC[obj].name;
		var position = measureAMC[obj].value;
		$('#f1adaptedAMC').append('<li class="list-group-item list-group-item-info" title="'+item+'">' + item + '<span class="badge pull-right">'+position+'</span></li>');
	}
}

function listASC() {
	var f1MeasureAdapted = Helper.getF1MeasureAdapted();
	var measureASC;
	for ( obj in f1MeasureAdapted) {
		if(f1MeasureAdapted[obj].key == 'asc') {
			measureASC = f1MeasureAdapted[obj].value;
		}
	}
	for ( obj in measureASC) {
		var item = measureASC[obj].name;
		var position = measureASC[obj].value;
		$('#f1adaptedASC').append('<li class="list-group-item list-group-item-info" title="'+item+'">' + item + '<span class="badge pull-right">'+position+'</span></li>');
	}
}