var failuresList = new Array();

$(function(){
	loadFailuresList();
});

function loadFailuresList(){
	failuresList.push('util.TestLogicalLineReader.testSimpleFile');
	failuresList.push('util.TestLogicalLineReader.testBackSlashRemains');
	failuresList.push('util.TestLogicalLineReader.testRead');
	failuresList.push('util.TestLogicalLineReader.testLineWithSpaces');
}

function getFailures(){
	return failuresList;
}
