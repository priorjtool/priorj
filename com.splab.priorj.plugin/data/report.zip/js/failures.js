var failuresList = new Array();

/**
* Main function
*/
$(function(){
	loadFailuresList();
});

/**
* Loading the list.
*/
function loadFailuresList(){

}

/**
* Accessing the Test List.
*
*/
function getFailures(){
	return failuresList;
}