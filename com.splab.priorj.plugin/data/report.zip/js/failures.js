var failuresList = new Array();

$(function(){
	loadFailuresList();
});

function loadFailuresList(){
}

function getFailures(){
	return failuresList;
}
