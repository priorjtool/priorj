var ascTests = new Array();

/**
* Main function
*/
$(function(){
	loadListASC();
});

/**
* Loading the list.
*/
function loadListASC(){

}

/**
* Accessing the Test List.
*
*/
function getOrderASC(){
	return ascTests;
}
