package tests;
import org.junit.runner.JUnitCore;
import org.junit.runner.Request;
import org.junit.runner.Result;
public class RND {
	private int failureCount = 0;
	private int runCount = 0;
	private int errorCount = 0;
	private int firstFailure = 0;
	public void run(){
		try{
			JUnitCore jc = new JUnitCore();
			Result result = null;
			Class utilTestLogicalLineReader = Class.forName("util.TestLogicalLineReader");
			Request utilTestLogicalLineReadertestLineWithSpaces = Request.method(utilTestLogicalLineReader,"testLineWithSpaces");
			result = jc.run(utilTestLogicalLineReadertestLineWithSpaces);
			setResult("testLineWithSpaces",result);
			Class easyacceptscriptTestScript = Class.forName("easyaccept.script.TestScript");
			Request easyacceptscriptTestScripttestScript5 = Request.method(easyacceptscriptTestScript,"testScript5");
			result = jc.run(easyacceptscriptTestScripttestScript5);
			setResult("testScript5",result);
			Request easyacceptscriptTestScripttestScript6 = Request.method(easyacceptscriptTestScript,"testScript6");
			result = jc.run(easyacceptscriptTestScripttestScript6);
			setResult("testScript6",result);
			Class easyacceptscriptTestQuitProcessor = Class.forName("easyaccept.script.TestQuitProcessor");
			Request easyacceptscriptTestQuitProcessortestExecute = Request.method(easyacceptscriptTestQuitProcessor,"testExecute");
			result = jc.run(easyacceptscriptTestQuitProcessortestExecute);
			setResult("testExecute",result);
			Request easyacceptscriptTestScripttestScript10 = Request.method(easyacceptscriptTestScript,"testScript10");
			result = jc.run(easyacceptscriptTestScripttestScript10);
			setResult("testScript10",result);
			Request utilTestLogicalLineReadertestUnread = Request.method(utilTestLogicalLineReader,"testUnread");
			result = jc.run(utilTestLogicalLineReadertestUnread);
			setResult("testUnread",result);
			Class easyacceptscriptTestExpectErrorProcessor = Class.forName("easyaccept.script.TestExpectErrorProcessor");
			Request easyacceptscriptTestExpectErrorProcessortestExecute = Request.method(easyacceptscriptTestExpectErrorProcessor,"testExecute");
			result = jc.run(easyacceptscriptTestExpectErrorProcessortestExecute);
			setResult("testExecute",result);
			Class utilTestParameterTypeConverter = Class.forName("util.TestParameterTypeConverter");
			Request utilTestParameterTypeConvertertestConvertParam = Request.method(utilTestParameterTypeConverter,"testConvertParam");
			result = jc.run(utilTestParameterTypeConvertertestConvertParam);
			setResult("testConvertParam",result);
			Request easyacceptscriptTestScripttestScript2 = Request.method(easyacceptscriptTestScript,"testScript2");
			result = jc.run(easyacceptscriptTestScripttestScript2);
			setResult("testScript2",result);
			Request utilTestLogicalLineReadertestRead = Request.method(utilTestLogicalLineReader,"testRead");
			result = jc.run(utilTestLogicalLineReadertestRead);
			setResult("testRead",result);
			Class easyacceptscriptTestExecuteScriptProcessor = Class.forName("easyaccept.script.TestExecuteScriptProcessor");
			Request easyacceptscriptTestExecuteScriptProcessortestExecuteScriptProcessor = Request.method(easyacceptscriptTestExecuteScriptProcessor,"testExecuteScriptProcessor");
			result = jc.run(easyacceptscriptTestExecuteScriptProcessortestExecuteScriptProcessor);
			setResult("testExecuteScriptProcessor",result);
			Class easyacceptscriptTestStackTraceProcessor = Class.forName("easyaccept.script.TestStackTraceProcessor");
			Request easyacceptscriptTestStackTraceProcessortestUnexpectedException = Request.method(easyacceptscriptTestStackTraceProcessor,"testUnexpectedException");
			result = jc.run(easyacceptscriptTestStackTraceProcessortestUnexpectedException);
			setResult("testUnexpectedException",result);
			Request utilTestLogicalLineReadertestSimpleFile = Request.method(utilTestLogicalLineReader,"testSimpleFile");
			result = jc.run(utilTestLogicalLineReadertestSimpleFile);
			setResult("testSimpleFile",result);
			Class easyacceptscriptTestExpectWithinProcessor = Class.forName("easyaccept.script.TestExpectWithinProcessor");
			Request easyacceptscriptTestExpectWithinProcessortestWithin1 = Request.method(easyacceptscriptTestExpectWithinProcessor,"testWithin1");
			result = jc.run(easyacceptscriptTestExpectWithinProcessortestWithin1);
			setResult("testWithin1",result);
			Class easyacceptscriptTestEqualFilesProcessor = Class.forName("easyaccept.script.TestEqualFilesProcessor");
			Request easyacceptscriptTestEqualFilesProcessortestExecute = Request.method(easyacceptscriptTestEqualFilesProcessor,"testExecute");
			result = jc.run(easyacceptscriptTestEqualFilesProcessortestExecute);
			setResult("testExecute",result);
			Request utilTestLogicalLineReadertestMixedRead = Request.method(utilTestLogicalLineReader,"testMixedRead");
			result = jc.run(utilTestLogicalLineReadertestMixedRead);
			setResult("testMixedRead",result);
			Request easyacceptscriptTestScripttestScript9 = Request.method(easyacceptscriptTestScript,"testScript9");
			result = jc.run(easyacceptscriptTestScripttestScript9);
			setResult("testScript9",result);
			Request easyacceptscriptTestScripttestScript4 = Request.method(easyacceptscriptTestScript,"testScript4");
			result = jc.run(easyacceptscriptTestScripttestScript4);
			setResult("testScript4",result);
			Request easyacceptscriptTestScripttestScript8 = Request.method(easyacceptscriptTestScript,"testScript8");
			result = jc.run(easyacceptscriptTestScripttestScript8);
			setResult("testScript8",result);
			Request easyacceptscriptTestScripttestScript11 = Request.method(easyacceptscriptTestScript,"testScript11");
			result = jc.run(easyacceptscriptTestScripttestScript11);
			setResult("testScript11",result);
			Request easyacceptscriptTestScripttestScript1 = Request.method(easyacceptscriptTestScript,"testScript1");
			result = jc.run(easyacceptscriptTestScripttestScript1);
			setResult("testScript1",result);
			Request easyacceptscriptTestStackTraceProcessortestUnexpectedException = Request.method(easyacceptscriptTestStackTraceProcessor,"testUnexpectedException");
			result = jc.run(easyacceptscriptTestStackTraceProcessortestUnexpectedException);
			setResult("testUnexpectedException",result);
			Request easyacceptscriptTestScripttestParameterPassingSyntax = Request.method(easyacceptscriptTestScript,"testParameterPassingSyntax");
			result = jc.run(easyacceptscriptTestScripttestParameterPassingSyntax);
			setResult("testParameterPassingSyntax",result);
			Request utilTestLogicalLineReadertestBackSlashRemains = Request.method(utilTestLogicalLineReader,"testBackSlashRemains");
			result = jc.run(utilTestLogicalLineReadertestBackSlashRemains);
			setResult("testBackSlashRemains",result);
			Request utilTestLogicalLineReadertestLineWithSpacesReadByCharacter = Request.method(utilTestLogicalLineReader,"testLineWithSpacesReadByCharacter");
			result = jc.run(utilTestLogicalLineReadertestLineWithSpacesReadByCharacter);
			setResult("testLineWithSpacesReadByCharacter",result);
			Request utilTestLogicalLineReadertestComment = Request.method(utilTestLogicalLineReader,"testComment");
			result = jc.run(utilTestLogicalLineReadertestComment);
			setResult("testComment",result);
			Request easyacceptscriptTestScripttestScript7 = Request.method(easyacceptscriptTestScript,"testScript7");
			result = jc.run(easyacceptscriptTestScripttestScript7);
			setResult("testScript7",result);
			Request easyacceptscriptTestScripttestScript12 = Request.method(easyacceptscriptTestScript,"testScript12");
			result = jc.run(easyacceptscriptTestScripttestScript12);
			setResult("testScript12",result);
			Request easyacceptscriptTestScripttestMethodMatch = Request.method(easyacceptscriptTestScript,"testMethodMatch");
			result = jc.run(easyacceptscriptTestScripttestMethodMatch);
			setResult("testMethodMatch",result);
			Request easyacceptscriptTestScripttestExpectDifferent = Request.method(easyacceptscriptTestScript,"testExpectDifferent");
			result = jc.run(easyacceptscriptTestScripttestExpectDifferent);
			setResult("testExpectDifferent",result);
			Request easyacceptscriptTestScripttestScript3 = Request.method(easyacceptscriptTestScript,"testScript3");
			result = jc.run(easyacceptscriptTestScripttestScript3);
			setResult("testScript3",result);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private void setResult(String testCaseName,Result result){
		System.out.println("TestCase: " + testCaseName +" " + getStatus(result));
		runCount += result.getRunCount();
		failureCount += result.getFailureCount();
		if (!result.wasSuccessful() && firstFailure  == 0)
		firstFailure = runCount;
	}
	private String getStatus(Result result){
		int failureCount = result.getFailureCount();
		if(failureCount > 0) return "[FAILURE]";
		else return "[ACCEPTED]";
	}
	public void printResult(){
		System.out.println("=================== Test Suite Prioritized - PriorJ =================");
		System.out.println("Run: " + this.runCount);
		System.out.println("Faults: " + this.failureCount);
		System.out.println("Errors: " + this.errorCount);
	System.out.println("First Failure: " + this.firstFailure);
	}
	public static void main(String[] args) {
		RND st = new RND();
		st.run();
		st.printResult();
	}
}
